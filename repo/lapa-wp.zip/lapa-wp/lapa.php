<?php
/*
Plugin Name: LaPa WP
Plugin URI: http://lapa.ndhost.ru
Description: Система "умного" кэширования
Version: 2.9.1
Author: Владислав Пономарев
Author URI: http://lapa.ndhost.ru
*/
wp_enqueue_script('lapa-wp',plugins_url( 'lapa.pre.js', __FILE__ ));
?>